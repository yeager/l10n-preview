"""L10n Preview - PO/TS file preview tool."""
__version__ = "0.1.0"
